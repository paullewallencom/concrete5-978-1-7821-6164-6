<?php defined('C5_EXECUTE') or die('Access Denied.') ?>

<footer>
    <p>© <?php echo SITE . ' ' . date('Y') ?></p>
</footer>

</div>

</div>

<?php Loader::element('footer_required') ?>

</body>
</html>
